package Ecom.payment_service.enums;

public enum PaymentStatus {
    PENDING, SUCCESS, FAILED, REFUNDED
}